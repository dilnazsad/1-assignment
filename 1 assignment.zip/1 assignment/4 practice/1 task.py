sum = int(input('Price of 1 kg:'))
for i in range(1, 11):
    print('Price of', i, 'kg is', sum)
    sum += sum