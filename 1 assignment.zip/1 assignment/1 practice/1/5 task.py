res = float(input('Enter the result:\n'))
print('your number is', (((res/2)-8)/5))