n = 34
while n < 66:
    n += 2
    print(n)
