for n in range(1, 101):
    if n == 50 or n == 99:
        continue
    print(n)
    n += 1
