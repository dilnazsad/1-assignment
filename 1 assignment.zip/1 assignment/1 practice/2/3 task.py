def check(n):
    if n > 10:
        while n != 12 and n <= 15 or n == 18:
            return True
    else:
        return False


a = 14
print(check(a))
