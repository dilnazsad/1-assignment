n1 = int(input('First number: '))
operation = str(input('Operation: '))
n2 = int(input('Second number: '))
if operation == "+":
    print(n1 + n2)
elif operation == "-":
    print(n1 - n2)
elif operation == "*":
    print(n1 * n2)
elif operation == "/":
    print(n1 / n2)
