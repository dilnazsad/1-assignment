import math
x = 2
y = 1
A = math.pow(math.pow(x, y), x) + math.pow(x, math.pow(x, y)) - math.pow(x, 4)
print("Answer is: " + format(A))
