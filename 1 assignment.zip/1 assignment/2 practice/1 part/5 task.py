import math
x = 3
y = 0.2
A = (5 * x * y / math.pow(x, 3) - 4) + math.exp(math.pow(x, 2)) + math.sqrt(math.pow(math.cos(y), 2)) - math.pow(y, 2)
print("Answer is: " + format(A))
