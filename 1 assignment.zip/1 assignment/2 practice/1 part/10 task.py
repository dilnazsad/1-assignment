import math
x = 3
y = 1
z = 3
A = (2 * 3 * 4) / (math.pow(math.sin(x), 3) + math.pow(math.tan(y), 3) - math.sqrt(math.pow(z, x -y)))
print("Answer is: " + format(A))
