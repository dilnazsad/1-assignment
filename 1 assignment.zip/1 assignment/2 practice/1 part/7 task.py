import math
x = 3
y = 1
z = 2
A = math.pow(4, x * y) - math.pow(x, y * z) + math.pow(x * y, z)
print("Answer is: " + format(A))
